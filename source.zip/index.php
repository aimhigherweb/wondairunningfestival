<?php
/**
 * The main template file
 *
 *
 * @package Wondai Country Running Festival
 * @version 1.0
 */

get_header(); ?>

<div class="container">
    <h2>Hello World</h2>
</div>

<?php get_footer();